"""
ALPD: Adaptive Latent Pruning Diffusion
evaluate.py — FID, reconstruction MSE, channel activity, runtime
"""

import os, json, time, argparse
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torchvision.utils import save_image

from models import ALPDModel
from diffusion import DDPMScheduler


# ── args ─────────────────────────────────────────────────────────────────────

def get_args():
    p = argparse.ArgumentParser()
    p.add_argument('--baseline_ckpt',   type=str, required=True)
    p.add_argument('--alpd_ckpt',       type=str, required=True)
    p.add_argument('--out_dir',         type=str, default='/kaggle/working/outputs/eval')
    p.add_argument('--data_dir',        type=str, default='/kaggle/working/data')
    p.add_argument('--n_samples',       type=int, default=1000)
    p.add_argument('--diffusion_steps', type=int, default=200)
    p.add_argument('--batch_size',      type=int, default=64)
    p.add_argument('--seed',            type=int, default=0)
    return p.parse_args()


# ── load ─────────────────────────────────────────────────────────────────────

def load_model(ckpt_path, device):
    ckpt  = torch.load(ckpt_path, map_location=device)
    a     = ckpt['args']
    model = ALPDModel(latent_ch=a['latent_ch'], base_ch=a['base_ch'],
                      unet_base=a['base_ch'], t_dim=a['t_dim'],
                      use_pruning=(a['mode'] == 'alpd')).to(device)
    model.load_state_dict(ckpt['model'])
    model.eval()
    return model, a


# ── FID ──────────────────────────────────────────────────────────────────────

def extract_inception_features(imgs_tensor, device, batch_size=64):
    """
    imgs_tensor: [N, 3, H, W] float in [0,1]
    Returns: [N, 2048] numpy array
    """
    from torchvision.models import inception_v3, Inception_V3_Weights
    net = inception_v3(weights=Inception_V3_Weights.DEFAULT,
                       transform_input=False).to(device)
    net.eval()

    feats = []
    def hook(m, i, o):
        feats.append(o.detach().cpu().flatten(1).numpy())
    h = net.avgpool.register_forward_hook(hook)

    resize = transforms.Resize((299, 299), antialias=True)
    for start in range(0, len(imgs_tensor), batch_size):
        batch = imgs_tensor[start:start+batch_size].to(device)
        batch = torch.stack([resize(img) for img in batch])
        with torch.no_grad():
            net(batch)

    h.remove()
    return np.concatenate(feats, axis=0)


def compute_fid(mu1, sig1, mu2, sig2):
    from scipy.linalg import sqrtm
    diff    = mu1 - mu2
    covmean = sqrtm(sig1 @ sig2)
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    return float(diff @ diff + np.trace(sig1 + sig2 - 2 * covmean))


# ── helpers ──────────────────────────────────────────────────────────────────

@torch.no_grad()
def generate_images(model, sched, n, device, steps, latent_hw=8):
    imgs, bs = [], 32
    for s in range(0, n, bs):
        b      = min(bs, n - s)
        z      = sched.sample(model.unet, (b, model.latent_ch, latent_hw, latent_hw),
                              device, steps=steps)
        recon  = model.vae.decode(z)
        imgs.append((recon.cpu().clamp(-1, 1) + 1) / 2)
    return torch.cat(imgs)[:n]


@torch.no_grad()
def recon_mse(model, loader, device):
    total, n = 0., 0
    for x, _ in loader:
        x = x.to(device)
        recon, *_ = model.vae(x)
        total += F.mse_loss(recon, x, reduction='sum').item()
        n     += x.shape[0]
    return total / n


@torch.no_grad()
def channel_activity(model, loader, device, n_batches=20):
    """Returns dict: class_idx → mean mask array [C]"""
    if not model.use_pruning:
        return None
    class_masks = {i: [] for i in range(10)}
    for i, (x, labels) in enumerate(loader):
        if i >= n_batches:
            break
        x = x.to(device)
        _, z, _, _ = model.vae(x)
        mask = model.importance(z)          # [B, C]
        for j in range(x.shape[0]):
            class_masks[labels[j].item()].append(mask[j].cpu().numpy())
    return {k: np.stack(v).mean(0) for k, v in class_masks.items() if v}


def runtime_benchmark(model, sched, device, steps=50, runs=5):
    shape = (8, model.latent_ch, 8, 8)
    times = []
    for _ in range(runs):
        t0 = time.time()
        with torch.no_grad():
            sched.sample(model.unet, shape, device, steps=steps)
        times.append(time.time() - t0)
    return float(np.mean(times)), float(np.std(times))


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    args   = get_args()
    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(args.out_dir, exist_ok=True)

    print("Loading checkpoints...")
    baseline, _ = load_model(args.baseline_ckpt, device)
    alpd,     _ = load_model(args.alpd_ckpt,     device)

    val_ds = datasets.CIFAR10(
        args.data_dir, train=False, download=True,
        transform=transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5]*3, [0.5]*3),
        ]))
    val_loader = DataLoader(val_ds, batch_size=args.batch_size,
                            shuffle=False, num_workers=2)

    sched   = DDPMScheduler(T=1000, device=device)
    results = {}

    # params
    results['baseline_params'] = sum(p.numel() for p in baseline.parameters())
    results['alpd_params']     = sum(p.numel() for p in alpd.parameters())

    # reconstruction MSE
    print("Reconstruction MSE...")
    results['baseline_recon_mse'] = recon_mse(baseline, val_loader, device)
    results['alpd_recon_mse']     = recon_mse(alpd,     val_loader, device)

    # runtime
    print("Runtime benchmark...")
    results['baseline_runtime_mean'], results['baseline_runtime_std'] = \
        runtime_benchmark(baseline, sched, device)
    results['alpd_runtime_mean'],     results['alpd_runtime_std']     = \
        runtime_benchmark(alpd,     sched, device)

    # channel activity
    print("Channel activity...")
    act = channel_activity(alpd, val_loader, device)
    if act:
        mean_mask = np.mean(list(act.values()), axis=0)
        results['alpd_mean_mask_per_channel'] = mean_mask.tolist()
        results['alpd_active_channels_mean']  = float((mean_mask > 0.5).sum())
        class_names = ['airplane','automobile','bird','cat','deer',
                       'dog','frog','horse','ship','truck']
        per_class = {class_names[k]: v.tolist() for k, v in act.items()}
        with open(os.path.join(args.out_dir, 'per_class_masks.json'), 'w') as f:
            json.dump(per_class, f, indent=2)
        print("  per_class_masks.json saved")

    # FID
    print(f"Generating {args.n_samples} samples for FID...")
    try:
        from scipy.linalg import sqrtm
        gen_base = generate_images(baseline, sched, args.n_samples,
                                   device, args.diffusion_steps)
        gen_alpd = generate_images(alpd,     sched, args.n_samples,
                                   device, args.diffusion_steps)
        real_imgs = torch.cat([(x.clamp(-1,1)+1)/2 for x,_ in val_loader])[:args.n_samples]

        print("  Extracting Inception features...")
        f_real = extract_inception_features(real_imgs, device)
        f_base = extract_inception_features(gen_base,  device)
        f_alpd = extract_inception_features(gen_alpd,  device)

        mu_r, sig_r = f_real.mean(0), np.cov(f_real, rowvar=False)
        results['baseline_fid'] = compute_fid(mu_r, sig_r, f_base.mean(0), np.cov(f_base, rowvar=False))
        results['alpd_fid']     = compute_fid(mu_r, sig_r, f_alpd.mean(0), np.cov(f_alpd, rowvar=False))

        save_image(gen_base[:64], os.path.join(args.out_dir, 'samples_baseline.png'), nrow=8)
        save_image(gen_alpd[:64], os.path.join(args.out_dir, 'samples_alpd.png'),     nrow=8)
        print(f"  Baseline FID: {results['baseline_fid']:.2f}")
        print(f"  ALPD     FID: {results['alpd_fid']:.2f}")

    except ImportError:
        print("  scipy missing — pip install scipy — skipping FID")
        results['fid_note'] = 'scipy not installed'
    except Exception as e:
        print(f"  FID failed: {e}")
        results['fid_error'] = str(e)

    with open(os.path.join(args.out_dir, 'eval_results.json'), 'w') as f:
        json.dump(results, f, indent=2)

    print("\n=== SUMMARY ===")
    for k, v in results.items():
        if not isinstance(v, list):
            print(f"  {k}: {v}")


if __name__ == '__main__':
    main()
