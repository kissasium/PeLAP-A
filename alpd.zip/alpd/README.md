# ALPD: Adaptive Latent Pruning Diffusion
### PeLAP-A — Preprint Prototype

---

## Overview

ALPD introduces a lightweight **importance predictor** into the latent diffusion pipeline. Rather than treating all latent channels equally, an MLP learns channel-wise importance scores that suppress redundant latent dimensions during diffusion. The model learns which channels to keep and which to ignore — jointly with VAE reconstruction and diffusion training.

```
Image → VAE Encoder → z → Importance Predictor → mask
                              ↓
                         z_pruned = z ⊙ mask
                              ↓
                         UNet Denoiser
                              ↓
                         VAE Decoder → Image
```

**Loss:** `L = L_vae + L_diffusion + λ · mean(mask)`

---

## Files

| File | Purpose |
|------|---------|
| `models.py` | VAE, ImportancePredictor, LightUNet, ALPDModel |
| `diffusion.py` | DDPM noise schedule, forward/reverse process |
| `train.py` | Training loop for baseline and ALPD |
| `ablation.py` | Sweep λ_sparse values |
| `evaluate.py` | FID, MSE, runtime, channel activity |
| `visualize.py` | 6 publication-quality figures |
| `ALPD_Kaggle.ipynb` | End-to-end Kaggle notebook |

---

## Kaggle Setup

1. **Create a new Kaggle notebook** with GPU accelerator (P100 or T4).
2. **Upload the source files** as a Kaggle Dataset named `alpd-src`:
   - Upload: `models.py`, `diffusion.py`, `train.py`, `evaluate.py`, `visualize.py`, `ablation.py`
3. **Upload `ALPD_Kaggle.ipynb`** as your notebook.
4. **Add the dataset** to the notebook: *Add Data → Your Datasets → alpd-src*
5. Run cells in order.

All outputs are saved under `/kaggle/working/outputs/`.

---

## Expected Runtimes (Kaggle P100)

| Step | Time |
|------|------|
| Baseline training (100 ep) | ~50 min |
| ALPD training (100 ep) | ~55 min |
| Ablation (5 λ × 30 ep) | ~70 min |
| Evaluation (FID 1k) | ~20 min |
| Visualization | ~5 min |
| **Total** | **~3.5 hr** |

For a quick prototype run, use `--epochs 30` and `--n_samples 500`.

---

## Model Architecture

### VAE
- **Encoder:** 3-layer CNN with residual blocks → μ, logvar of shape [B, 4, 8, 8]
- **Decoder:** Transposed CNN with residual blocks → 3×32×32
- **Latent space:** 4 channels at 8×8 spatial resolution

### Importance Predictor
```
z [B,4,8,8] → GlobalAvgPool → [B,4] → Linear(4,32) → ReLU → Linear(32,4) → Sigmoid → mask [B,4]
```

### UNet
- Encoder: 2 downsampling stages with time-step conditioning
- Bottleneck: 1 residual block
- Decoder: 2 upsampling stages with skip connections
- ~2.5M parameters total (both baseline and ALPD share the same UNet)

---

## Experiments

### Table 1: Baseline vs. ALPD

| Metric | Baseline | ALPD |
|--------|----------|------|
| Parameters | — | — |
| Recon. MSE | — | — |
| FID ↓ | — | — |
| Runtime (s) | — | — |
| Active Channels | 4/4 | ?/4 |

*(Fill in after running evaluate.py)*

### Figure 1: Training curves
### Figure 2: Per-class channel importance heatmap
### Figure 3: Mask value distributions per channel
### Figure 4: Ablation — λ_sparse vs. FID and active channels
### Figure 5: Reconstruction grid (original / baseline / ALPD)
### Figure 6: Results table

---

## Research Questions Addressed

1. **How many latent channels are actually necessary?** → Figure 2, Figure 3
2. **Can we reduce computation without losing quality?** → Table 1, Figure 4
3. **Do different image classes activate different channels?** → Figure 2

---

## Citation

```bibtex
@article{alpd2025,
  title={Adaptive Latent Pruning for Lightweight Diffusion Models},
  author={...},
  year={2025},
  note={Preprint}
}
```
