"""
ALPD: Adaptive Latent Pruning Diffusion
ablation.py — Sweep λ_sparse to study sparsity-quality tradeoff
"""

import os, json, time, argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torch.optim.lr_scheduler import CosineAnnealingLR

from models import ALPDModel
from diffusion import DDPMScheduler


def get_args():
    p = argparse.ArgumentParser()
    p.add_argument('--lambdas', nargs='+', type=float,
                   default=[0.0001, 0.0005, 0.001, 0.005, 0.01])
    p.add_argument('--epochs',     type=int,   default=30)
    p.add_argument('--batch_size', type=int,   default=128)
    p.add_argument('--lr',         type=float, default=2e-4)
    p.add_argument('--latent_ch',  type=int,   default=4)
    p.add_argument('--base_ch',    type=int,   default=64)
    p.add_argument('--t_dim',      type=int,   default=128)
    p.add_argument('--T',          type=int,   default=1000)
    p.add_argument('--data_dir',   type=str,   default='/kaggle/working/data')
    p.add_argument('--out_dir',    type=str,   default='/kaggle/working/outputs/eval')
    p.add_argument('--seed',       type=int,   default=42)
    return p.parse_args()


def get_loader(data_dir, batch_size, train=True):
    T = transforms.Compose([
        transforms.RandomHorizontalFlip() if train else transforms.Lambda(lambda x: x),
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3, [0.5]*3),
    ])
    ds = datasets.CIFAR10(data_dir, train=train, download=True, transform=T)
    return DataLoader(ds, batch_size=batch_size, shuffle=train,
                      num_workers=2, pin_memory=True, drop_last=train)


def vae_loss(recon, x, mu, logvar, kl_w=0.001):
    return F.mse_loss(recon, x) + kl_w * (-0.5 * torch.mean(
        1 + logvar - mu.pow(2) - logvar.exp()))


def run_one(lam, args, device):
    train_loader = get_loader(args.data_dir, args.batch_size, train=True)
    val_loader   = get_loader(args.data_dir, args.batch_size, train=False)

    model = ALPDModel(latent_ch=args.latent_ch, base_ch=args.base_ch,
                      unet_base=args.base_ch, t_dim=args.t_dim,
                      use_pruning=True).to(device)
    sched     = DDPMScheduler(T=args.T, device=device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    lr_sched  = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-5)

    for epoch in range(args.epochs):
        model.train()
        for x, _ in train_loader:
            x = x.to(device)
            recon, z, mu, logvar = model.vae(x)
            L_vae    = vae_loss(recon, x, mu, logvar)
            z_p, mask = model.get_mask(z)          # no detach — gradients flow
            L_diff   = sched.diffusion_loss(model.unet, z_p)
            L_sp     = mask.mean()
            L        = L_vae + L_diff + lam * L_sp
            optimizer.zero_grad(); L.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        lr_sched.step()

    # eval
    model.eval()
    val_diff = val_active = n = 0
    with torch.no_grad():
        for x, _ in val_loader:
            x = x.to(device)
            _, z, _, _ = model.vae(x)
            z_p, mask  = model.get_mask(z)
            val_diff   += sched.diffusion_loss(model.unet, z_p).item() * x.shape[0]
            # active_channels = avg number of channels with mask > 0.5 per sample
            val_active += (mask > 0.5).float().sum(dim=1).mean().item() * x.shape[0]
            n += x.shape[0]

    return {'lambda_sparse': lam,
            'val_diff_loss': val_diff / n,
            'active_channels': val_active / n}


def main():
    args = get_args()
    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(args.out_dir, exist_ok=True)

    results = []
    for lam in args.lambdas:
        print(f"\n── λ_sparse = {lam} ──")
        t0  = time.time()
        res = run_one(lam, args, device)
        res['time_sec'] = time.time() - t0
        results.append(res)
        print(f"  val_diff={res['val_diff_loss']:.4f} | "
              f"active_ch={res['active_channels']:.2f} | "
              f"time={res['time_sec']:.0f}s")

    out_path = os.path.join(args.out_dir, 'ablation_results.json')
    with open(out_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved {out_path}")
    print(f"\n{'λ_sparse':<12} {'Val Diff':<14} {'Active Ch'}")
    print('─' * 40)
    for r in results:
        print(f"{r['lambda_sparse']:<12.5f} {r['val_diff_loss']:<14.4f} {r['active_channels']:.2f}")


if __name__ == '__main__':
    main()
