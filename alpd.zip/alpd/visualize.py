"""
ALPD: Adaptive Latent Pruning Diffusion
visualize.py — Publication-quality figures
"""

import os, json, argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

from models import ALPDModel


CIFAR_CLASSES = ['airplane','automobile','bird','cat','deer',
                 'dog','frog','horse','ship','truck']

BLUE   = '#2563EB'
ORANGE = '#EA580C'
GRAY   = '#6B7280'
RED    = '#DC2626'

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'figure.dpi': 150})


def get_args():
    p = argparse.ArgumentParser()
    p.add_argument('--alpd_ckpt',        type=str, required=True)
    p.add_argument('--baseline_ckpt',    type=str, required=True)
    p.add_argument('--eval_dir',         type=str, default='/kaggle/working/outputs/eval')
    p.add_argument('--history_alpd',     type=str, default='/kaggle/working/outputs/alpd/history.json')
    p.add_argument('--history_baseline', type=str, default='/kaggle/working/outputs/baseline/history.json')
    p.add_argument('--out_dir',          type=str, default='/kaggle/working/outputs/figures')
    p.add_argument('--data_dir',         type=str, default='/kaggle/working/data')
    return p.parse_args()


def load_model(ckpt_path, device):
    ckpt  = torch.load(ckpt_path, map_location=device)
    a     = ckpt['args']
    model = ALPDModel(latent_ch=a['latent_ch'], base_ch=a['base_ch'],
                      unet_base=a['base_ch'], t_dim=a['t_dim'],
                      use_pruning=(a['mode'] == 'alpd')).to(device)
    model.load_state_dict(ckpt['model'])
    model.eval()
    return model, a


def save(fig, path):
    fig.savefig(path, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved {path}")


# ── Fig 1: Training curves ────────────────────────────────────────────────────

def fig1_training_curves(ha, hb, out_dir):
    ea = [r['epoch'] for r in ha]
    eb = [r['epoch'] for r in hb]

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    axes[0].plot(eb, [r['val_total'] for r in hb], color=GRAY,   lw=2, label='Baseline')
    axes[0].plot(ea, [r['val_total'] for r in ha], color=BLUE,   lw=2, label='ALPD')
    axes[0].set(xlabel='Epoch', ylabel='Val Loss', title='Total Validation Loss')
    axes[0].legend()

    axes[1].plot(eb, [r['val_diff'] for r in hb], color=GRAY,  lw=2, label='Baseline')
    axes[1].plot(ea, [r['val_diff'] for r in ha], color=BLUE,  lw=2, label='ALPD')
    axes[1].set(xlabel='Epoch', ylabel='Diffusion MSE', title='Diffusion Loss')
    axes[1].legend()

    axes[2].plot(ea, [r['val_active_ch'] for r in ha],
                 color=ORANGE, lw=2, marker='o', markersize=3)
    axes[2].axhline(4, color=GRAY, ls='--', lw=1, label='Max (4)')
    axes[2].set(xlabel='Epoch', ylabel='Active Channels', title='Channel Activity (ALPD)')
    axes[2].legend()

    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig1_training_curves.pdf'))


# ── Fig 2: Per-class heatmap ──────────────────────────────────────────────────

def fig2_class_heatmap(per_class_path, out_dir):
    if not os.path.exists(per_class_path):
        print(f"Skipping fig2 — {per_class_path} not found"); return
    with open(per_class_path) as f:
        data = json.load(f)

    n_ch   = len(next(iter(data.values())))
    matrix = np.array([data.get(c, [0]*n_ch) for c in CIFAR_CLASSES])

    fig, ax = plt.subplots(figsize=(8, 5))
    cmap = LinearSegmentedColormap.from_list('alpd', ['#F9FAFB', BLUE])
    im   = ax.imshow(matrix, aspect='auto', cmap=cmap, vmin=0, vmax=1)
    ax.set_xticks(range(n_ch));         ax.set_xticklabels([f'Ch {i+1}' for i in range(n_ch)])
    ax.set_yticks(range(len(CIFAR_CLASSES))); ax.set_yticklabels(CIFAR_CLASSES)
    ax.set_title('Per-Class Channel Importance', fontsize=13, pad=12)
    for i in range(len(CIFAR_CLASSES)):
        for j in range(n_ch):
            ax.text(j, i, f'{matrix[i,j]:.2f}', ha='center', va='center',
                    fontsize=9, color='white' if matrix[i,j] > 0.6 else '#111827')
    plt.colorbar(im, ax=ax, fraction=0.03, pad=0.02, label='Importance Score')
    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig2_class_importance_heatmap.pdf'))


# ── Fig 3: Mask distributions ─────────────────────────────────────────────────

def fig3_mask_distributions(alpd_model, val_loader, device, out_dir):
    masks = []
    with torch.no_grad():
        for x, _ in val_loader:
            masks.append(alpd_model.importance(alpd_model.vae.encode(x.to(device))[0]).cpu().numpy())
            if len(masks) >= 20: break
    masks = np.concatenate(masks, axis=0)   # [N, C]
    n_ch  = masks.shape[1]

    fig, axes = plt.subplots(1, n_ch, figsize=(3.5*n_ch, 4), sharey=True)
    if n_ch == 1: axes = [axes]
    for ch, ax in enumerate(axes):
        v = masks[:, ch]
        ax.hist(v, bins=30, color=BLUE, alpha=0.8, edgecolor='white')
        ax.axvline(0.5, color=RED, ls='--', lw=1.5)
        ax.set(xlabel='Mask Value', title=f'Ch {ch+1}  μ={v.mean():.2f}')
        if ch == 0: ax.set_ylabel('Count')
    fig.suptitle('Importance Mask Distributions per Channel', fontsize=13)
    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig3_mask_distributions.pdf'))


# ── Fig 4: Ablation ───────────────────────────────────────────────────────────

def fig4_ablation(ablation_path, out_dir):
    if not os.path.exists(ablation_path):
        print(f"Skipping fig4 — {ablation_path} not found"); return
    with open(ablation_path) as f:
        data = json.load(f)

    lambdas = [d['lambda_sparse']  for d in data]
    losses  = [d['val_diff_loss']  for d in data]
    active  = [d['active_channels'] for d in data]

    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax2 = ax1.twinx()
    ax1.plot(lambdas, losses,  color=BLUE,   marker='o', lw=2, label='Val Diff Loss')
    ax2.plot(lambdas, active,  color=ORANGE, marker='s', lw=2, label='Active Channels')
    ax1.set_xscale('log')
    ax1.set(xlabel='λ_sparse', ylabel='Val Diffusion Loss')
    ax2.set_ylabel('Avg. Active Channels')
    ax1.set_title('Ablation: λ_sparse vs. Loss and Channel Activity')
    l1, lb1 = ax1.get_legend_handles_labels()
    l2, lb2 = ax2.get_legend_handles_labels()
    ax1.legend(l1+l2, lb1+lb2, loc='upper left')
    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig4_ablation.pdf'))


# ── Fig 5: Reconstruction grid ────────────────────────────────────────────────

def fig5_reconstruction_grid(baseline, alpd_model, val_loader, device, out_dir):
    xb, _ = next(iter(val_loader))
    xb = xb[:8].to(device)

    with torch.no_grad():
        recon_b, *_  = baseline.vae(xb)
        z, mu, logvar = baseline.vae.encoder(xb)[0], *baseline.vae.encoder(xb)
        # use alpd model properly
        recon_a, z_a, mu_a, lv_a = alpd_model.vae(xb)
        z_p, mask = alpd_model.get_mask(z_a)
        recon_ap  = alpd_model.vae.decode(z_p)

    def to01(t): return (t.clamp(-1,1)+1)/2

    rows   = [to01(xb), to01(recon_b), to01(recon_ap)]
    labels = ['Original', 'Baseline Recon.', 'ALPD Recon. (pruned)']

    fig, axes = plt.subplots(3, 8, figsize=(16, 6))
    for ri, (row, lbl) in enumerate(zip(rows, labels)):
        for ci in range(8):
            axes[ri, ci].imshow(row[ci].cpu().permute(1,2,0).numpy())
            axes[ri, ci].axis('off')
        axes[ri, 0].set_ylabel(lbl, fontsize=10, labelpad=8)
    fig.suptitle('Reconstruction Comparison', fontsize=13)
    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig5_reconstruction_grid.pdf'))


# ── Fig 6: Results table ──────────────────────────────────────────────────────

def fig6_results_table(eval_path, out_dir):
    if not os.path.exists(eval_path):
        print(f"Skipping fig6 — {eval_path} not found"); return
    with open(eval_path) as f:
        r = json.load(f)

    def fmt_fid(key):
        v = r.get(key, 'N/A')
        return f'{v:.2f}' if isinstance(v, float) else str(v)

    rows = [
        ['Metric',          'Baseline',                                  'ALPD (Ours)',                          'Δ'],
        ['Parameters',      f"{r.get('baseline_params',0):,}",           f"{r.get('alpd_params',0):,}",          f"{r.get('alpd_params',0)-r.get('baseline_params',0):+,}"],
        ['Recon. MSE',      f"{r.get('baseline_recon_mse',0):.4f}",      f"{r.get('alpd_recon_mse',0):.4f}",    f"{r.get('alpd_recon_mse',0)-r.get('baseline_recon_mse',0):+.4f}"],
        ['FID ↓',           fmt_fid('baseline_fid'),                     fmt_fid('alpd_fid'),                   '—'],
        ['Runtime (s)',     f"{r.get('baseline_runtime_mean',0):.3f}",   f"{r.get('alpd_runtime_mean',0):.3f}", f"{r.get('alpd_runtime_mean',0)-r.get('baseline_runtime_mean',0):+.3f}"],
        ['Active Channels', '4 / 4',                                     f"{r.get('alpd_active_channels_mean',0):.1f} / 4", '—'],
    ]

    fig, ax = plt.subplots(figsize=(10, 3.5))
    ax.axis('off')
    tbl = ax.table(cellText=rows[1:], colLabels=rows[0], loc='center', cellLoc='center')
    tbl.auto_set_font_size(False); tbl.set_fontsize(11); tbl.scale(1.3, 1.8)
    for j in range(4):
        tbl[(0,j)].set_facecolor(BLUE)
        tbl[(0,j)].set_text_props(color='white', fontweight='bold')
    ax.set_title('Quantitative Comparison: Baseline vs. ALPD', fontsize=13, pad=14)
    fig.tight_layout()
    save(fig, os.path.join(out_dir, 'fig6_results_table.pdf'))


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    args   = get_args()
    os.makedirs(args.out_dir, exist_ok=True)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    print("Loading models...")
    baseline,   _ = load_model(args.baseline_ckpt, device)
    alpd_model, _ = load_model(args.alpd_ckpt,     device)

    val_loader = DataLoader(
        datasets.CIFAR10(args.data_dir, train=False, download=True,
                         transform=transforms.Compose([
                             transforms.ToTensor(),
                             transforms.Normalize([0.5]*3,[0.5]*3)])),
        batch_size=64, shuffle=False, num_workers=2)

    with open(args.history_alpd)     as f: ha = json.load(f)
    with open(args.history_baseline) as f: hb = json.load(f)

    fig1_training_curves(ha, hb, args.out_dir)
    fig2_class_heatmap(os.path.join(args.eval_dir, 'per_class_masks.json'), args.out_dir)
    fig3_mask_distributions(alpd_model, val_loader, device, args.out_dir)
    fig4_ablation(os.path.join(args.eval_dir, 'ablation_results.json'), args.out_dir)
    fig5_reconstruction_grid(baseline, alpd_model, val_loader, device, args.out_dir)
    fig6_results_table(os.path.join(args.eval_dir, 'eval_results.json'), args.out_dir)

    print(f"\nAll figures saved to {args.out_dir}")


if __name__ == '__main__':
    main()
