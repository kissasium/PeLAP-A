"""
ALPD: Adaptive Latent Pruning Diffusion
train.py — Training loop for baseline and ALPD
"""

import os, time, json, argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torchvision.utils import save_image
from torch.optim.lr_scheduler import CosineAnnealingLR

from models import ALPDModel
from diffusion import DDPMScheduler


# ── args ─────────────────────────────────────────────────────────────────────

def get_args():
    p = argparse.ArgumentParser()
    p.add_argument('--mode',          choices=['baseline','alpd'], default='alpd')
    p.add_argument('--epochs',        type=int,   default=100)
    p.add_argument('--batch_size',    type=int,   default=128)
    p.add_argument('--lr',            type=float, default=2e-4)
    p.add_argument('--lambda_sparse', type=float, default=0.001)
    p.add_argument('--latent_ch',     type=int,   default=4)
    p.add_argument('--base_ch',       type=int,   default=64)
    p.add_argument('--t_dim',         type=int,   default=128)
    p.add_argument('--T',             type=int,   default=1000)
    p.add_argument('--data_dir',      type=str,   default='/kaggle/working/data')
    p.add_argument('--out_dir',       type=str,   default='/kaggle/working/outputs')
    p.add_argument('--save_every',    type=int,   default=10)
    p.add_argument('--seed',          type=int,   default=42)
    return p.parse_args()


# ── data ─────────────────────────────────────────────────────────────────────

def get_loaders(data_dir, batch_size):
    T_train = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3, [0.5]*3),
    ])
    T_val = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3, [0.5]*3),
    ])
    train_ds = datasets.CIFAR10(data_dir, train=True,  download=True, transform=T_train)
    val_ds   = datasets.CIFAR10(data_dir, train=False, download=True, transform=T_val)
    kw = dict(num_workers=2, pin_memory=True)
    return (DataLoader(train_ds, batch_size=batch_size, shuffle=True,  drop_last=True, **kw),
            DataLoader(val_ds,   batch_size=batch_size, shuffle=False, **kw))


# ── loss ─────────────────────────────────────────────────────────────────────

def vae_loss(recon, x, mu, logvar, kl_w=0.001):
    recon_l = F.mse_loss(recon, x)
    kl      = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())
    return recon_l + kl_w * kl, recon_l


# ── one epoch ────────────────────────────────────────────────────────────────

def run_epoch(model, sched, loader, optimizer, device, lam, use_pruning, train):
    model.train() if train else model.eval()
    tot = dict(vae=0., diff=0., sparse=0., total=0., active_ch=0.)
    n   = 0

    ctx = torch.enable_grad() if train else torch.no_grad()
    with ctx:
        for x, _ in loader:
            x = x.to(device)
            B = x.shape[0]

            # VAE
            recon, z, mu, logvar = model.vae(x)
            L_vae, recon_l = vae_loss(recon, x, mu, logvar)

            # Mask  — NOTE: do NOT detach z here so importance predictor gets gradients
            z_p, mask = model.get_mask(z)

            # Diffusion
            L_diff = sched.diffusion_loss(model.unet, z_p)

            # Sparsity
            L_sp = mask.mean() if use_pruning else torch.zeros(1, device=device)

            L = L_vae + L_diff + lam * L_sp

            if train:
                optimizer.zero_grad()
                L.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

            tot['vae']       += recon_l.item() * B
            tot['diff']      += L_diff.item()  * B
            tot['sparse']    += L_sp.item()    * B
            tot['total']     += L.item()       * B
            # count how many channels are active (mask > 0.5) per sample
            tot['active_ch'] += (mask > 0.5).float().sum(dim=1).mean().item() * B
            n += B

    return {k: v/n for k, v in tot.items()}


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    args        = get_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device      = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_pruning = (args.mode == 'alpd')

    out_dir = os.path.join(args.out_dir, args.mode)
    for sub in ['', '/checkpoints', '/samples']:
        os.makedirs(out_dir + sub, exist_ok=True)

    print(f"\n{'='*50}")
    print(f" Mode: {args.mode.upper()}  |  Device: {device}")
    print(f" Pruning: {use_pruning}  |  λ_sparse: {args.lambda_sparse}")
    print(f"{'='*50}\n")

    train_loader, val_loader = get_loaders(args.data_dir, args.batch_size)

    model = ALPDModel(latent_ch=args.latent_ch, base_ch=args.base_ch,
                      unet_base=args.base_ch, t_dim=args.t_dim,
                      use_pruning=use_pruning).to(device)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")

    sched     = DDPMScheduler(T=args.T, device=device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    lr_sched  = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-5)

    history, best_val = [], float('inf')
    t0_total = time.time()

    for ep in range(1, args.epochs + 1):
        t0 = time.time()
        tr = run_epoch(model, sched, train_loader, optimizer, device,
                       args.lambda_sparse, use_pruning, train=True)
        va = run_epoch(model, sched, val_loader,   optimizer, device,
                       args.lambda_sparse, use_pruning, train=False)
        lr_sched.step()

        print(f"Ep {ep:03d}/{args.epochs} | "
              f"Train: {tr['total']:.4f} (vae={tr['vae']:.4f} "
              f"diff={tr['diff']:.4f} sp={tr['sparse']:.4f}) | "
              f"Val: {va['total']:.4f} | "
              f"ActiveCh: {va['active_ch']:.2f}/{args.latent_ch} | "
              f"{time.time()-t0:.1f}s")

        row = {'epoch': ep, **{f'train_{k}': v for k,v in tr.items()},
                             **{f'val_{k}':   v for k,v in va.items()},
               'epoch_time': time.time()-t0}
        history.append(row)

        if va['total'] < best_val:
            best_val = va['total']
            torch.save({'epoch': ep, 'model': model.state_dict(),
                        'optimizer': optimizer.state_dict(),
                        'val_total': va['total'], 'args': vars(args)},
                       f"{out_dir}/checkpoints/best.pt")

        if ep % args.save_every == 0 or ep == args.epochs:
            torch.save({'epoch': ep, 'model': model.state_dict(), 'args': vars(args)},
                       f"{out_dir}/checkpoints/ep{ep:03d}.pt")
            model.eval()
            with torch.no_grad():
                xb, _ = next(iter(val_loader))
                xb     = xb[:8].to(device)
                recon, z, mu, logvar = model.vae(xb)
                grid   = torch.cat([xb, recon], dim=0)
                save_image(grid * 0.5 + 0.5,
                           f"{out_dir}/samples/recon_ep{ep:03d}.png", nrow=8)
            model.train()

        with open(f"{out_dir}/history.json", 'w') as f:
            json.dump(history, f, indent=2)

    total_time = time.time() - t0_total
    print(f"\nDone in {total_time/60:.1f} min. Best val: {best_val:.4f}")
    with open(f"{out_dir}/summary.json", 'w') as f:
        json.dump({'mode': args.mode, 'use_pruning': use_pruning,
                   'total_params': sum(p.numel() for p in model.parameters()),
                   'total_train_time_sec': total_time,
                   'best_val_loss': best_val,
                   'final_active_channels': history[-1]['val_active_ch'],
                   'args': vars(args)}, f, indent=2)


if __name__ == '__main__':
    main()
