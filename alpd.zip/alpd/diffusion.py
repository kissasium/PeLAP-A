"""
ALPD: Adaptive Latent Pruning Diffusion
diffusion.py — DDPM noise schedule and diffusion utilities
"""

import torch
import torch.nn.functional as F


class DDPMScheduler:
    """Linear beta schedule DDPM."""

    def __init__(self, T=1000, beta_start=1e-4, beta_end=0.02, device='cpu'):
        self.T      = T
        self.device = device

        betas               = torch.linspace(beta_start, beta_end, T)
        alphas              = 1.0 - betas
        alphas_cumprod      = torch.cumprod(alphas, dim=0)
        alphas_cumprod_prev = F.pad(alphas_cumprod[:-1], (1, 0), value=1.0)
        posterior_variance  = betas * (1. - alphas_cumprod_prev) / (1. - alphas_cumprod)

        # store all on CPU, move in .to()
        self._buf = {
            'betas':                          betas,
            'alphas':                         alphas,
            'alphas_cumprod':                 alphas_cumprod,
            'alphas_cumprod_prev':            alphas_cumprod_prev,
            'sqrt_alphas_cumprod':            alphas_cumprod.sqrt(),
            'sqrt_one_minus_alphas_cumprod':  (1 - alphas_cumprod).sqrt(),
            'sqrt_recip_alphas':              (1.0 / alphas).sqrt(),
            'posterior_variance':             posterior_variance,
        }
        self.to(device)

    def to(self, device):
        self.device = device
        for k, v in self._buf.items():
            setattr(self, k, v.to(device))
        return self

    # ── forward process ──────────────────────────────────────────────────────

    def q_sample(self, x0, t, noise=None):
        """x0, t → noisy x_t.  All tensors on same device as x0."""
        if noise is None:
            noise = torch.randn_like(x0)
        sa  = self.sqrt_alphas_cumprod[t][:, None, None, None]
        som = self.sqrt_one_minus_alphas_cumprod[t][:, None, None, None]
        return sa * x0 + som * noise, noise

    # ── reverse process ──────────────────────────────────────────────────────

    def p_sample(self, model, x_t, t_scalar):
        """One DDPM reverse step."""
        t_vec = torch.full((x_t.shape[0],), t_scalar,
                           device=x_t.device, dtype=torch.long)
        with torch.no_grad():
            eps = model(x_t, t_vec)
        beta        = self.betas[t_scalar]
        recip_alpha = self.sqrt_recip_alphas[t_scalar]
        som         = self.sqrt_one_minus_alphas_cumprod[t_scalar]
        mean        = recip_alpha * (x_t - beta / som * eps)
        if t_scalar == 0:
            return mean
        noise = torch.randn_like(x_t)
        return mean + self.posterior_variance[t_scalar].sqrt() * noise

    @torch.no_grad()
    def sample(self, model, shape, device, steps=None):
        """Full reverse diffusion from pure noise."""
        steps = steps or self.T
        x = torch.randn(shape, device=device)
        for t in reversed(range(steps)):
            x = self.p_sample(model, x, t)
        return x

    # ── training loss ────────────────────────────────────────────────────────

    def diffusion_loss(self, model, x0):
        """Simple DDPM noise-prediction MSE loss."""
        B  = x0.shape[0]
        t  = torch.randint(0, self.T, (B,), device=x0.device, dtype=torch.long)
        x_noisy, noise = self.q_sample(x0, t)
        noise_pred     = model(x_noisy, t)
        return F.mse_loss(noise_pred, noise)
