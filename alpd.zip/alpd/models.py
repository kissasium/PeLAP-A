"""
ALPD: Adaptive Latent Pruning Diffusion
models.py — VAE, Importance Predictor, UNet
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# ─────────────────────────── VAE ───────────────────────────

class ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.net = nn.Sequential(
            nn.GroupNorm(8, ch), nn.SiLU(),
            nn.Conv2d(ch, ch, 3, padding=1),
            nn.GroupNorm(8, ch), nn.SiLU(),
            nn.Conv2d(ch, ch, 3, padding=1),
        )

    def forward(self, x):
        return x + self.net(x)


class Encoder(nn.Module):
    """3×32×32 → μ, logvar of shape [B, latent_ch, 8, 8]"""

    def __init__(self, in_ch=3, base_ch=64, latent_ch=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, base_ch, 3, padding=1),           # 32×32
            ResBlock(base_ch),
            nn.Conv2d(base_ch, base_ch * 2, 4, stride=2, padding=1),  # 16×16
            ResBlock(base_ch * 2),
            nn.Conv2d(base_ch * 2, base_ch * 2, 4, stride=2, padding=1),  # 8×8
            ResBlock(base_ch * 2),
            nn.GroupNorm(8, base_ch * 2),
            nn.SiLU(),
        )
        self.mu_head     = nn.Conv2d(base_ch * 2, latent_ch, 1)
        self.logvar_head = nn.Conv2d(base_ch * 2, latent_ch, 1)

    def forward(self, x):
        h = self.net(x)
        return self.mu_head(h), self.logvar_head(h)


class Decoder(nn.Module):
    """[B, latent_ch, 8, 8] → 3×32×32"""

    def __init__(self, out_ch=3, base_ch=64, latent_ch=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(latent_ch, base_ch * 2, 3, padding=1),
            ResBlock(base_ch * 2),
            nn.ConvTranspose2d(base_ch * 2, base_ch * 2, 4, stride=2, padding=1),  # 16×16
            ResBlock(base_ch * 2),
            nn.ConvTranspose2d(base_ch * 2, base_ch, 4, stride=2, padding=1),       # 32×32
            ResBlock(base_ch),
            nn.GroupNorm(8, base_ch),
            nn.SiLU(),
            nn.Conv2d(base_ch, out_ch, 3, padding=1),
            nn.Tanh(),
        )

    def forward(self, z):
        return self.net(z)


class VAE(nn.Module):
    def __init__(self, in_ch=3, base_ch=64, latent_ch=4):
        super().__init__()
        self.encoder   = Encoder(in_ch, base_ch, latent_ch)
        self.decoder   = Decoder(in_ch, base_ch, latent_ch)
        self.latent_ch = latent_ch

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + std * torch.randn_like(std)

    def encode(self, x):
        mu, logvar = self.encoder(x)
        z = self.reparameterize(mu, logvar)
        return z, mu, logvar

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        z, mu, logvar = self.encode(x)
        return self.decoder(z), z, mu, logvar


# ─────────────────────────── Importance Predictor ───────────────────────────

class ImportancePredictor(nn.Module):
    """
    GlobalAvgPool → MLP → sigmoid → per-channel mask in (0,1).
    Input:  z  [B, C, H, W]
    Output: mask [B, C]

    The final layer bias is initialized to +3.0 so sigmoid(3)≈0.95,
    meaning all channels start nearly open. Sparsity loss then
    gradually closes unimportant ones during training.
    """

    def __init__(self, latent_ch=4, hidden=32):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(latent_ch, hidden),
            nn.ReLU(),
            nn.Linear(hidden, latent_ch),
        )
        # Initialize final layer bias to +3 → sigmoid(3) ≈ 0.95
        # Channels start fully open; sparsity loss closes unimportant ones
        nn.init.constant_(self.mlp[-1].bias, 3.0)
        nn.init.zeros_(self.mlp[-1].weight)

    def forward(self, z):
        pooled = z.mean(dim=(-2, -1))           # [B, C]
        return torch.sigmoid(self.mlp(pooled))  # [B, C]


# ─────────────────────────── Sinusoidal time embedding ───────────────────────

class SinusoidalPE(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, t):
        half   = self.dim // 2
        freqs  = torch.exp(
            -math.log(10000) * torch.arange(half, device=t.device).float() / (half - 1)
        )
        args = t.float()[:, None] * freqs[None]     # [B, half]
        return torch.cat([args.sin(), args.cos()], dim=-1)  # [B, dim]


# ─────────────────────────── UNet blocks (NO internal residual skip) ─────────

class UNetBlock(nn.Module):
    """
    Two conv layers + time conditioning.
    No skip connection inside the block — avoids any spatial mismatch.
    Channel change is handled by conv1 directly.
    """

    def __init__(self, in_ch, out_ch, t_dim):
        super().__init__()
        self.norm1  = nn.GroupNorm(min(8, in_ch), in_ch)
        self.conv1  = nn.Conv2d(in_ch, out_ch, 3, padding=1)
        self.t_proj = nn.Linear(t_dim, out_ch)
        self.norm2  = nn.GroupNorm(min(8, out_ch), out_ch)
        self.conv2  = nn.Conv2d(out_ch, out_ch, 3, padding=1)

    def forward(self, x, t_emb):
        h = self.conv1(F.silu(self.norm1(x)))                          # change channels
        h = h + self.t_proj(F.silu(t_emb))[:, :, None, None]          # add time
        h = self.conv2(F.silu(self.norm2(h)))                          # refine
        return h


# ─────────────────────────── Lightweight UNet ────────────────────────────────

class LightUNet(nn.Module):
    """
    UNet for 8×8 latents.

    Spatial flow:
        enc1 :  [B, latent_ch, 8, 8] → [B, C,   8, 8]   (no downsample yet)
        down  :  8×8 → 4×4
        mid1  :  [B, C,   4, 4] → [B, C2,  4, 4]
        mid2  :  [B, C2,  4, 4] → [B, C2,  4, 4]
        up    :  4×4 → 8×8
        dec1  :  cat([B,C2,8,8], [B,C,8,8]) = [B, C2+C, 8, 8] → [B, C, 8, 8]
        out   :  [B, C, 8, 8] → [B, latent_ch, 8, 8]

    C  = base_ch      = 64
    C2 = base_ch * 2  = 128
    """

    def __init__(self, latent_ch=4, base_ch=64, t_dim=128):
        super().__init__()
        C  = base_ch
        C2 = base_ch * 2

        self.t_embed = nn.Sequential(
            SinusoidalPE(t_dim),
            nn.Linear(t_dim, t_dim * 2),
            nn.SiLU(),
            nn.Linear(t_dim * 2, t_dim),
        )

        self.enc1 = UNetBlock(latent_ch, C,  t_dim)   # 8×8,  out: [B, C,  8, 8]
        self.down = nn.AvgPool2d(2)                    #       out: [B, C,  4, 4]
        self.mid1 = UNetBlock(C,  C2, t_dim)           # 4×4,  out: [B, C2, 4, 4]
        self.mid2 = UNetBlock(C2, C2, t_dim)           # 4×4,  out: [B, C2, 4, 4]
        self.up   = nn.Upsample(scale_factor=2, mode='nearest')  # [B, C2, 8, 8]

        # After concat with enc1 skip: C2 + C channels
        self.dec1 = UNetBlock(C2 + C, C, t_dim)       # 8×8,  out: [B, C,  8, 8]
        self.out  = nn.Conv2d(C, latent_ch, 1)         #       out: [B, latent_ch, 8, 8]

    def forward(self, x, t):
        t_emb = self.t_embed(t)                           # [B, t_dim]

        e1 = self.enc1(x,            t_emb)               # [B, C,  8, 8]
        m  = self.mid1(self.down(e1), t_emb)              # [B, C2, 4, 4]
        m  = self.mid2(m,            t_emb)               # [B, C2, 4, 4]
        d  = self.up(m)                                   # [B, C2, 8, 8]
        d  = self.dec1(torch.cat([d, e1], dim=1), t_emb) # [B, C,  8, 8]
        return self.out(d)                                # [B, latent_ch, 8, 8]


# ─────────────────────────── Full ALPD System ────────────────────────────────

class ALPDModel(nn.Module):
    def __init__(self, latent_ch=4, base_ch=64, unet_base=64, t_dim=128,
                 use_pruning=True):
        super().__init__()
        self.vae        = VAE(latent_ch=latent_ch, base_ch=base_ch)
        self.importance = ImportancePredictor(latent_ch=latent_ch)
        self.unet       = LightUNet(latent_ch=latent_ch, base_ch=unet_base, t_dim=t_dim)
        self.use_pruning = use_pruning
        self.latent_ch   = latent_ch

    def get_mask(self, z):
        if self.use_pruning:
            mask    = self.importance(z)                          # [B, C]
            z_pruned = z * mask.unsqueeze(-1).unsqueeze(-1)       # [B, C, H, W]
            return z_pruned, mask
        else:
            mask = torch.ones(z.shape[0], self.latent_ch, device=z.device)
            return z, mask
